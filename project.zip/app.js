// app.js
// Main controller for Wealth Tracker

// Safe Lucide mockup in case of CDN block/offline mode
if (typeof lucide === "undefined") {
  window.lucide = {
    createIcons: () => console.warn("Lucide icons failed to load.")
  };
}

// --- CONSTANTS & DATA SEEDING ---
const SEED_TRANSACTIONS = [
  { id: "af21dbca2", date: "2/5/2026", type: "Expense", platform: "Make", total: 100.00, category: "ค่าอาหาร", location: "", remark: "" },
  { id: "af21dbca12", date: "2/5/2026", type: "Expense", platform: "TTB", total: 58.00, category: "ค่าอาหาร", location: "GRAB", remark: "" },
  { id: "af21dbca13", date: "2/5/2026", type: "Expense", platform: "TTB", total: 200.00, category: "ค่าอาหาร", location: "GRAB", remark: "" },
  { id: "af21dbca14", date: "2/5/2026", type: "Expense", platform: "TTB", total: 185.00, category: "ค่าอาหาร", location: "GRAB", remark: "" },
  { id: "af21dbca15", date: "3/5/2026", type: "Expense", platform: "TTB", total: 160.00, category: "ค่าอาหาร", location: "GRAB", remark: "" },
  { id: "af21dbca16", date: "3/5/2026", type: "Expense", platform: "TTB", total: 150.00, category: "ความบันเทิง", location: "STEAM", remark: "" },
  { id: "af21dbca17", date: "3/5/2026", type: "Expense", platform: "TTB", total: 2398.75, category: "ค่าท่องเที่ยว", location: "Traveloka", remark: "" },
  { id: "af21dbca3", date: "5/5/2026", type: "Expense", platform: "Make", total: 1190.00, category: "ค่ายิม", location: "Ace Fitness", remark: "Fixed Cost" },
  { id: "af21dbca4", date: "5/5/2026", type: "Expense", platform: "Make", total: 10.00, category: "ค่าอาหาร", location: "Ace Fitness", remark: "" },
  { id: "af21dbca5", date: "5/5/2026", type: "Expense", platform: "Make", total: 70.00, category: "ค่าอาหาร", location: "ไก่โอปป้า", remark: "" },
  { id: "af21dbca6", date: "5/5/2026", type: "Expense", platform: "Make", total: 70.00, category: "ค่าอาหาร", location: "Bean There Cafe", remark: "" },
  { id: "af21dbca7", date: "6/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "Bean There Cafe", remark: "" },
  { id: "af21dbca8", date: "6/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "Bean There Cafe", remark: "" },
  { id: "af21dbca9", date: "6/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "Bean There Cafe", remark: "" },
  { id: "af21dbca10", date: "6/5/2026", type: "Expense", platform: "Make", total: 59.00, category: "ค่าอาหาร", location: "เลอมง-รางเมง", remark: "" },
  { id: "af21dbca11", date: "6/5/2026", type: "Expense", platform: "Make", total: 1800.00, category: "ค่าท่องเที่ยว", location: "เรือเร็ว ลมพระยา", remark: "" },
  { id: "af21dbca18", date: "7/5/2026", type: "Expense", platform: "Make", total: 60.00, category: "ค่าอาหาร", location: "ข้าวขาหมูทองสุข", remark: "" },
  { id: "af21dbca24", date: "7/5/2026", type: "Expense", platform: "Make", total: 430.00, category: "ค่าอาหาร", location: "เจ๊สาวหมูกระทะ", remark: "" },
  { id: "af21dbca22", date: "8/5/2026", type: "Expense", platform: "Make", total: 276.00, category: "ค่าอาหาร", location: "Bonus Suki", remark: "" },
  { id: "af21dbca23", date: "8/5/2026", type: "Expense", platform: "Make", total: 90.00, category: "ค่าเดินทาง", location: "PT", remark: "" },
  { id: "af21dbca19", date: "9/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "BB", remark: "" },
  { id: "af21dbca20", date: "9/5/2026", type: "Expense", platform: "Make", total: 60.00, category: "ค่าอาหาร", location: "", remark: "" },
  { id: "af21dbca21", date: "9/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "", remark: "" },
  { id: "af21dbca26", date: "9/5/2026", type: "Expense", platform: "Make", total: 330.00, category: "ค่าอาหาร", location: "เหมียว หมาล่า", remark: "" },
  { id: "af21dbca27", date: "9/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "", remark: "" },
  { id: "af21dbca28", date: "9/5/2026", type: "Income", platform: "Make", total: 4500.00, category: "ค่าสอนพิเศษ", location: "พี่มะปราง", remark: "" },
  { id: "af21dbca29", date: "9/5/2026", type: "Income", platform: "Make", total: 4950.00, category: "ค่าเงินว่างงาน", location: "SSO", remark: "" },
  { id: "af21dbca30", date: "9/5/2026", type: "Income", platform: "Make", total: 180.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "af21dbca25", date: "10/5/2026", type: "Expense", platform: "Make", total: 152.00, category: "ค่าอาหาร", location: "", remark: "" },
  { id: "af21dbca31", date: "10/5/2026", type: "Expense", platform: "Make", total: 80.00, category: "ค่าอาหาร", location: "ตลาดสำเภาทอง", remark: "" },
  { id: "af21dbca1", date: "11/5/2026", type: "Expense", platform: "Make", total: 20.00, category: "ทำบุญ", location: "", remark: "" },
  { id: "af21dbca32", date: "11/5/2026", type: "Expense", platform: "Make", total: 155.00, category: "ค่าอาหาร", location: "เฉลา", remark: "" },
  { id: "af21dbca33", date: "11/5/2026", type: "Expense", platform: "Make", total: 45.00, category: "ค่าอาหาร", location: "เฉลา", remark: "" },
  { id: "af21dbca34", date: "11/5/2026", type: "Expense", platform: "Make", total: 524.00, category: "ค่าเดินทาง", location: "รฟท", remark: "BKK Trip May 26" },
  { id: "af21dbca36", date: "11/5/2026", type: "Expense", platform: "Make", total: 524.00, category: "ค่าเดินทาง", location: "รฟท", remark: "BKK Trip May 26" },
  { id: "df9e6a7c", date: "5/12/2026", type: "Expense", platform: "Make", total: 642.00, category: "ค่าอินเตอร์เน็ต", location: "3BB", remark: "Fixed Cost" },
  { id: "9aaef4b2", date: "5/12/2026", type: "Expense", platform: "Make", total: 100.00, category: "ค่าอาหาร", location: "ข้าวขาหมูทองสุข", remark: "" },
  { id: "06229d99", date: "5/12/2026", type: "Income", platform: "TTB", total: 390.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "b07639b8", date: "5/12/2026", type: "Income", platform: "TTB", total: 180.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "1c49774c", date: "5/12/2026", type: "Expense", platform: "Make", total: 45.00, category: "ค่าส่งของ", location: "J&T", remark: "" },
  { id: "d83db5eb", date: "5/12/2026", type: "Expense", platform: "Make", total: 142.00, category: "ช้อปปิ้ง", location: "Shopee", remark: "" },
  { id: "8e9f801c", date: "5/13/2026", type: "Expense", platform: "Make", total: 150.00, category: "ค่าอาหาร", location: "Grab", remark: "" },
  { id: "02dfb598", date: "5/13/2026", type: "Expense", platform: "Make", total: 10.00, category: "ค่าอาหาร", location: "Ace fitness", remark: "" },
  { id: "2dd264a7", date: "5/13/2026", type: "Expense", platform: "Make", total: 190.00, category: "ค่าอาหาร", location: "7-11", remark: "" },
  { id: "c3347091", date: "5/14/2026", type: "Expense", platform: "Make", total: 150.00, category: "ค่าอาหาร", location: "Grab", remark: "" },
  { id: "1f6dae29", date: "5/14/2026", type: "Expense", platform: "Make", total: 217.40, category: "ค่าอาหาร", location: "Tiktok", remark: "" },
  { id: "908953d0", date: "5/14/2026", type: "Expense", platform: "Make", total: 105.00, category: "ค่าเดินทาง", location: "รฟท", remark: "BKK Trip May 26" },
  { id: "1643cb9c", date: "5/15/2026", type: "Expense", platform: "Make", total: 120.00, category: "ค่าอาหาร", location: "ข้าวขาหมูทองสุข", remark: "" },
  { id: "7fdb8b3e", date: "5/16/2026", type: "Expense", platform: "Make", total: 140.00, category: "ค่าอาหาร", location: "Grab", remark: "" },
  { id: "a6f22b78", date: "5/16/2026", type: "Income", platform: "Make", total: 390.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "c856f736", date: "5/18/2026", type: "Expense", platform: "Make", total: 250.00, category: "ค่ารักษาพริกไทย", location: "หมอพุทสัตวแพทย์", remark: "" },
  { id: "8b23122f", date: "5/18/2026", type: "Expense", platform: "Make", total: 647.00, category: "ค่าอาหาร", location: "Makro", remark: "" },
  { id: "3b777c71", date: "5/18/2026", type: "Expense", platform: "Make", total: 130.00, category: "ค่าอาหาร", location: "ไก่ทอดบังดุลย์", remark: "" },
  { id: "26a5b34a", date: "5/21/2026", type: "Expense", platform: "Make", total: 310.00, category: "ค่าอาหาร", location: "ข้าวแกงปั๊ม PT พนม", remark: "" },
  { id: "da528a25", date: "5/21/2026", type: "Expense", platform: "Make", total: 240.00, category: "ค่าอาหาร", location: "เจ๊แป๋ว", remark: "" },
  { id: "e7c93278", date: "5/22/2026", type: "Expense", platform: "Make", total: 29.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "73cf9fd6", date: "5/22/2026", type: "Expense", platform: "Make", total: 435.00, category: "ค่าอาหาร", location: "Moshen", remark: "BKK Trip May 26" },
  { id: "ecd7051e", date: "5/22/2026", type: "Expense", platform: "Make", total: 23.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "6d677da5", date: "5/22/2026", type: "Expense", platform: "Make", total: 150.00, category: "ค่าอาหาร", location: "Fair Chocolate", remark: "BKK Trip May 26" },
  { id: "a082be40", date: "5/22/2026", type: "Expense", platform: "Make", total: 822.67, category: "ค่าอาหาร", location: "กะเทยชาบู", remark: "BKK Trip May 26" },
  { id: "5d20139a", date: "5/23/2026", type: "Expense", platform: "Make", total: 75.00, category: "ค่าอาหาร", location: "", remark: "BKK Trip May 26" },
  { id: "f91557b2", date: "5/23/2026", type: "Expense", platform: "Make", total: 52.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "f0d57015", date: "5/23/2026", type: "Expense", platform: "Make", total: 153.00, category: "ค่าอาหาร", location: "HMHM", remark: "BKK Trip May 26" },
  { id: "e72d15d8", date: "5/23/2026", type: "Expense", platform: "Make", total: 45.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "e2b8c798", date: "5/23/2026", type: "Expense", platform: "Make", total: 398.00, category: "ค่าอาหาร", location: "Lucky Suki", remark: "BKK Trip May 26" },
  { id: "9e8723d1", date: "5/23/2026", type: "Expense", platform: "Make", total: 60.00, category: "ค่าอาหาร", location: "", remark: "BKK Trip May 26" },
  { id: "991cf815", date: "5/23/2026", type: "Expense", platform: "Make", total: 262.00, category: "ค่าเดินทาง", location: "รฟท", remark: "BKK Trip May 26" },
  { id: "954ca671", date: "5/23/2026", type: "Expense", platform: "Make", total: 285.00, category: "ค่ายา", location: "ร้านยากรุงเทพ", remark: "BKK Trip May 26" },
  { id: "368a8d6a", date: "5/24/2026", type: "Expense", platform: "Make", total: 214.00, category: "ค่าอาหาร", location: "Myeongryun Jinsa Galbi", remark: "BKK Trip May 26" },
  { id: "60f68e3c", date: "5/24/2026", type: "Expense", platform: "Make", total: 152.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "e8e55610", date: "5/25/2026", type: "Expense", platform: "Make", total: 120.00, category: "ค่าอาหาร", location: "ร้านข้าวขาหมู SL", remark: "BKK Trip May 26" },
  { id: "e8e55611", date: "5/25/2026", type: "Expense", platform: "Make", total: 100.00, category: "ค่าอาหาร", location: "ร้านผลไม้หน้า SL", remark: "BKK Trip May 26" }, // Fixed ID collision
  { id: "d0ecbe4d", date: "5/25/2026", type: "Expense", platform: "Make", total: 18.00, category: "ช้อปปิ้ง", location: "7-11", remark: "BKK Trip May 26" },
  { id: "350d5017", date: "5/25/2026", type: "Expense", platform: "Make", total: 48.00, category: "ค่าอาหาร", location: "7-11", remark: "BKK Trip May 26" },
  { id: "18bd3676", date: "5/25/2026", type: "Expense", platform: "Make", total: 45.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "eb0d6de6", date: "5/25/2026", type: "Expense", platform: "Make", total: 45.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "7fa94344", date: "5/26/2026", type: "Expense", platform: "Make", total: 27.00, category: "ค่าเดินทาง", location: "Smile Bus", remark: "BKK Trip May 26" },
  { id: "9369e83b", date: "5/26/2026", type: "Expense", platform: "Make", total: 27.00, category: "ค่าเดินทาง", location: "Smile Bus", remark: "BKK Trip May 26" },
  { id: "3af97863", date: "5/26/2026", type: "Expense", platform: "Make", total: 90.00, category: "ค่าอาหาร", location: "Sara Cafe", remark: "BKK Trip May 26" },
  { id: "b9ce3c20", date: "5/26/2026", type: "Expense", platform: "Make", total: 639.00, category: "ค่าอาหาร", location: "Tibet Restaurant", remark: "BKK Trip May 26" },
  { id: "ac3a238c", date: "5/26/2026", type: "Expense", platform: "Make", total: 49.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "690d11ab", date: "5/26/2026", type: "Expense", platform: "Make", total: 82.00, category: "ค่าเดินทาง", location: "GRAB", remark: "BKK Trip May 26" },
  { id: "e706fd71", date: "5/27/2026", type: "Expense", platform: "Make", total: 160.00, category: "ค่าอาหาร", location: "ก๋วยจั๊บนายเอ็กซ์", remark: "BKK Trip May 26" },
  { id: "26b09cad", date: "5/27/2026", type: "Expense", platform: "Make", total: 150.00, category: "ค่าอาหาร", location: "Fair Chocolate", remark: "BKK Trip May 26" },
  { id: "3d520ef0", date: "5/27/2026", type: "Expense", platform: "Make", total: 110.00, category: "ค่าอาหาร", location: "Punjab Sweet", remark: "BKK Trip May 26" },
  { id: "a55ef5a8", date: "5/27/2026", type: "Expense", platform: "Make", total: 160.00, category: "ค่าอาหาร", location: "Tony Restaurant", remark: "BKK Trip May 26" },
  { id: "332aa6b5", date: "5/27/2026", type: "Expense", platform: "Make", total: 39.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "e0520ead", date: "5/27/2026", type: "Expense", platform: "Make", total: 58.00, category: "ค่าเดินทาง", location: "Bolt", remark: "BKK Trip May 26" },
  { id: "c0bbe076", date: "5/28/2026", type: "Expense", platform: "Make", total: 25.00, category: "ค่าเดินทาง", location: "รถบัสสุราษฎร์", remark: "" },
  { id: "b65b098b", date: "5/28/2026", type: "Expense", platform: "Make", total: 1213.00, category: "ค่าอาหาร", location: "Makro", remark: "" },
  { id: "52078557", date: "5/28/2026", type: "Expense", platform: "TTB", total: 469.20, category: "ค่าอาหาร", location: "Tiktok", remark: "" },
  { id: "3a727fbd", date: "5/29/2026", type: "Expense", platform: "Cr. So Fast", total: 850.00, category: "ค่าอาหาร", location: "Fit Whey", remark: "" },
  { id: "293b5bf9", date: "5/29/2026", type: "Expense", platform: "Make", total: 20.00, category: "ค่าอาหาร", location: "Ace Fitness", remark: "" },
  { id: "3b106338", date: "5/29/2026", type: "Expense", platform: "Cr. So Fast", total: 107.00, category: "ค่าเดินทาง", location: "MRT", remark: "BKK Trip May 26" },
  { id: "06229d999", date: "5/24/2026", type: "Income", platform: "TTB", total: 420.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "06229d991", date: "5/19/2026", type: "Income", platform: "TTB", total: 180.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "06229d992", date: "5/18/2026", type: "Income", platform: "TTB", total: 420.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "06229d993", date: "5/17/2026", type: "Income", platform: "TTB", total: 210.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "e44cf993", date: "5/30/2026", type: "Income", platform: "TTB", total: 420.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "" },
  { id: "b5a6da02", date: "5/31/2026", type: "Income", platform: "TTB", total: 420.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "Villa Commission" },
  { id: "91734688", date: "6/1/2026", type: "Income", platform: "TTB", total: 210.00, category: "ค่า Com Villa", location: "Sita Villa", remark: "Villa Commission" },
  { id: "9922ae79", date: "6/1/2026", type: "Expense", platform: "Make", total: 70.00, category: "ค่าอาหาร", location: "ร้านตามสั่งตลาดพนม", remark: "" },
  { id: "8fe25043", date: "6/1/2026", type: "Expense", platform: "Make", total: 50.00, category: "ค่าอาหาร", location: "ร้านผลไม้พนม", remark: "" },
  { id: "a9684598", date: "6/1/2026", type: "Expense", platform: "Cr. So Fast", total: 64.30, category: "ความบันเทิง", location: "STEAM", remark: "" },
  { id: "266456b8", date: "6/2/2026", type: "Expense", platform: "Tiktok Paylater", total: 247.80, category: "ค่าอาหาร", location: "Tiktok", remark: "" }
];

// --- APP GLOBAL STATE ---
let transactions = [];
let filteredTransactions = [];
let currentPage = 1;
const itemsPerPage = 15;
let isApiMode = false;
let monthlyChart = null;



// --- UTILITY FUNCTIONS ---

// Parses mixed format dates dynamically into ISO format YYYY-MM-DD
function parseCustomDate(dateStr) {
  if (!dateStr) return "";
  dateStr = dateStr.trim();
  
  if (/^\d{4}-\d{2}-\d{2}$/.test(dateStr)) {
    return dateStr;
  }
  
  const parts = dateStr.split(/[-/]/);
  if (parts.length !== 3) return dateStr;
  
  let p1 = parseInt(parts[0], 10);
  let p2 = parseInt(parts[1], 10);
  let yr = parseInt(parts[2], 10);
  if (yr < 100) yr += 2000;
  
  let day, month;
  if (p1 > 12) {
    day = p1;
    month = p2;
  } else if (p2 > 12) {
    day = p2;
    month = p1;
  } else {
    // Both parts are <= 12
    // If we're looking at 2026:
    // May records have 5 (either p1 or p2)
    // June records have 6 (either p1 or p2)
    if (p2 === 5) {
      month = 5;
      day = p1;
    } else if (p1 === 5) {
      month = 5;
      day = p2;
    } else if (p1 === 6) {
      month = 6;
      day = p2;
    } else if (p2 === 6) {
      month = 6;
      day = p1;
    } else {
      // Fallback
      day = p1;
      month = p2;
    }
  }
  
  const mm = String(month).padStart(2, "0");
  const dd = String(day).padStart(2, "0");
  return `${yr}-${mm}-${dd}`;
}

// Formats number into Thai Baht currency presentation
function formatCurrency(value) {
  return new Intl.NumberFormat("th-TH", {
    style: "currency",
    currency: "THB"
  }).format(value);
}

// Generates a short random ID
function generateId() {
  return Math.random().toString(36).substring(2, 11);
}

// Theme management
function initTheme() {
  const savedTheme = localStorage.getItem("wt_theme") || "dark";
  document.documentElement.setAttribute("data-theme", savedTheme);
  updateThemeIcon();
}

function updateThemeIcon() {
  const currentTheme = document.documentElement.getAttribute("data-theme");
  const themeBtn = document.getElementById("btn-toggle-theme");
  if (currentTheme === "light") {
    themeBtn.innerHTML = '<i data-lucide="moon"></i>';
  } else {
    themeBtn.innerHTML = '<i data-lucide="sun"></i>';
  }
  lucide.createIcons();
}

// Show popup success or error banner
function showStatus(text, type = "success") {
  const banner = document.getElementById("status-banner");
  const bannerText = document.getElementById("status-text");
  const bannerIcon = document.getElementById("status-icon");
  
  banner.className = `status-banner ${type}`;
  bannerText.innerText = text;
  
  // Set appropriate icon
  let iconName = "info";
  if (type === "success") iconName = "check-circle";
  if (type === "error") iconName = "alert-triangle";
  if (type === "warning") iconName = "alert-circle";
  
  bannerIcon.setAttribute("data-lucide", iconName);
  lucide.createIcons();
  
  banner.style.display = "flex";
  
  // Auto-hide after 5 seconds
  setTimeout(() => {
    banner.style.display = "none";
  }, 5000);
}

// --- DATABASE OPERATIONS (DUAL MODE) ---

// A safe JSON fetch wrapper that parses HTTP texts first to avoid JSON parse crashes
async function safeFetchJson(url, options = {}) {
  try {
    const res = await fetch(url, options);
    const text = await res.text();
    
    let data;
    try {
      data = JSON.parse(text);
    } catch (e) {
      console.error(`Failed to parse JSON response from ${url}. Raw response:`, text);
      return { ok: false, status: res.status, error: `เซิร์ฟเวอร์ตอบกลับรูปแบบไม่ถูกต้อง (HTTP ${res.status})` };
    }
    
    return { ok: res.ok, status: res.status, data };
  } catch (err) {
    console.error(`Network fetch error on ${url}:`, err);
    return { ok: false, status: 0, error: err.message || "การเชื่อมต่อเครือข่ายล้มเหลว" };
  }
}

// Verify if backend Cloudflare Page functions are responsive
let apiErrorDetail = "";
async function checkApiMode() {
  if (window.location.protocol === "file:") {
    isApiMode = false;
    return;
  }
  const res = await safeFetchJson("/api/transactions?limit=1");
  isApiMode = res.ok;
  if (!res.ok) {
    apiErrorDetail = res.error || "Unknown API check failure";
    console.warn("API check failed. Cloudflare Functions or D1 is not responding correctly:", apiErrorDetail);
  }
}

// Load transactions list
async function loadTransactions() {
  const modeBadge = document.getElementById("mode-badge");
  const modeText = document.getElementById("mode-text");
  
  if (isApiMode) {
    modeBadge.className = "type-tag income";
    modeText.innerText = "Cloudflare D1 SQL";
    try {
      const res = await safeFetchJson("/api/transactions");
      if (res.ok) {
        transactions = res.data;
      } else {
        throw new Error(res.error || "Failed to load D1 transactions");
      }
    } catch (e) {
      console.error(e);
      showStatus(`ดึงข้อมูลจาก Cloudflare D1 ล้มเหลว (${e.message}) พยายามสลับไปโหมด LocalStorage...`, "warning");
      loadLocalStorageTransactions();
    }
  } else {
    modeBadge.className = "type-tag expense";
    modeBadge.style.backgroundColor = "rgba(244, 63, 94, 0.1)";
    modeBadge.style.color = "var(--color-expense)";
    
    if (window.location.protocol !== "file:") {
      modeText.innerText = "Cloudflare API Error";
      showStatus(`ระบบหลังบ้าน Cloudflare ขัดข้อง: ${apiErrorDetail} (อาจยังไม่ได้ผูก D1 หรือกด Retry Deploy ในหน้าเว็บ Cloudflare)`, "error");
    } else {
      modeText.innerText = "Offline LocalStorage";
    }
    loadLocalStorageTransactions();
  }
  
  // Ensure date sorting: newest first, then by update order
  transactions.sort((a, b) => {
    const dDiff = b.date.localeCompare(a.date);
    if (dDiff !== 0) return dDiff;
    return (b.updated_at || 0) - (a.updated_at || 0);
  });
  
  buildFilters();
  applyFilters();
}

function loadLocalStorageTransactions() {
  let stored = localStorage.getItem("wealth_tracker_transactions");
  if (!stored) {
    // If opening for first time, initialize with parsed seed data
    const formattedSeed = SEED_TRANSACTIONS.map(t => ({
      ...t,
      date: parseCustomDate(t.date),
      updated_at: Date.now()
    }));
    localStorage.setItem("wealth_tracker_transactions", JSON.stringify(formattedSeed));
    transactions = formattedSeed;
  } else {
    transactions = JSON.parse(stored);
  }
}

// Insert or edit a transaction record
async function saveTransaction(transactionData) {
  const isEditing = !!transactionData.id;
  transactionData.updated_at = Date.now();
  
  if (!transactionData.id) {
    transactionData.id = generateId();
  }
  
  if (isApiMode) {
    try {
      const method = isEditing ? "PUT" : "POST";
      const res = await safeFetchJson("/api/transactions", {
        method: method,
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(transactionData)
      });
      
      if (res.ok) {

        showStatus(isEditing ? "แก้ไขรายการในฐานข้อมูลเสร็จเรียบร้อย" : "เพิ่มรายการใหม่ในฐานข้อมูลเสร็จเรียบร้อย", "success");
      } else {
        throw new Error(res.data?.error || res.error || "D1 save failed");
      }
    } catch (e) {
      console.error(e);
      showStatus(`บันทึกลง D1 ล้มเหลว! ${e.message}`, "error");
      return false;
    }
  } else {
    // LocalStorage CRUD logic
    if (isEditing) {
      const idx = transactions.findIndex(t => t.id === transactionData.id);
      if (idx !== -1) transactions[idx] = transactionData;
    } else {
      transactions.unshift(transactionData);
    }
    localStorage.setItem("wealth_tracker_transactions", JSON.stringify(transactions));
    showStatus(isEditing ? "แก้ไขข้อมูลในบราวเซอร์สำเร็จ" : "บันทึกข้อมูลรายการใหม่ลงบราวเซอร์สำเร็จ", "success");
  }
  
  await loadTransactions();
  return true;
}

// Delete a transaction record
async function deleteTransaction(id) {
  if (!id) return;
  
  if (isApiMode) {
    try {
      const res = await safeFetchJson(`/api/transactions?id=${id}`, {
        method: "DELETE"
      });
      
      if (res.ok) {

        showStatus("ลบรายการออกจากฐานข้อมูลแล้ว", "success");
      } else {
        throw new Error(res.data?.error || res.error || "D1 delete failed");
      }
    } catch (e) {
      console.error(e);
      showStatus(`ไม่สามารถลบรายการออกจาก D1 ได้: ${e.message}`, "error");
      return false;
    }
  } else {
    transactions = transactions.filter(t => t.id !== id);
    localStorage.setItem("wealth_tracker_transactions", JSON.stringify(transactions));
    showStatus("ลบรายการออกจากบราวเซอร์แล้ว", "success");
  }
  
  await loadTransactions();
  return true;
}



// --- FILTER & DATA BINDINGS ENGINE ---

// Build filters options dropdowns dynamically based on database entries
function buildFilters() {
  const typeFilter = document.getElementById("filter-type");
  const catFilter = document.getElementById("filter-category");
  const platFilter = document.getElementById("filter-platform");
  
  const selectedCat = catFilter.value;
  const selectedPlat = platFilter.value;
  
  // Extract unique categories & platforms
  const categories = [...new Set(transactions.map(t => t.category).filter(Boolean))].sort();
  const platforms = [...new Set(transactions.map(t => t.platform).filter(Boolean))].sort();
  
  // Populate category options
  catFilter.innerHTML = '<option value="">ทุกหมวดหมู่</option>';
  categories.forEach(c => {
    const opt = document.createElement("option");
    opt.value = c;
    opt.innerText = c;
    if (c === selectedCat) opt.selected = true;
    catFilter.appendChild(opt);
  });
  
  // Populate platform options
  platFilter.innerHTML = '<option value="">ทุกแพลตฟอร์ม</option>';
  platforms.forEach(p => {
    const opt = document.createElement("option");
    opt.value = p;
    opt.innerText = p;
    if (p === selectedPlat) opt.selected = true;
    platFilter.appendChild(opt);
  });
  
  // Build autocompletion lists for form entry
  window.autocompleteLists = {
    platform: platforms,
    category: categories,
    location: [...new Set(transactions.map(t => t.location).filter(Boolean))].sort()
  };
}

// Filter dataset on client side
function applyFilters() {
  const searchVal = document.getElementById("filter-search").value.toLowerCase().trim();
  const typeVal = document.getElementById("filter-type").value;
  const catVal = document.getElementById("filter-category").value;
  const platVal = document.getElementById("filter-platform").value;
  const startVal = document.getElementById("filter-start-date").value;
  const endVal = document.getElementById("filter-end-date").value;
  
  filteredTransactions = transactions.filter(t => {
    if (typeVal && t.type !== typeVal) return false;
    if (catVal && t.category !== catVal) return false;
    if (platVal && t.platform !== platVal) return false;
    
    if (startVal && t.date < startVal) return false;
    if (endVal && t.date > endVal) return false;
    
    if (searchVal) {
      const matchSearch = 
        t.category.toLowerCase().includes(searchVal) ||
        (t.location && t.location.toLowerCase().includes(searchVal)) ||
        (t.remark && t.remark.toLowerCase().includes(searchVal)) ||
        t.platform.toLowerCase().includes(searchVal);
      if (!matchSearch) return false;
    }
    
    return true;
  });
  
  currentPage = 1;
  updateKPIs();
  renderCharts();
  renderCategoryBreakdowns();
  renderTransactionsTable();
}

// Reset filters back to default
function resetFilters() {
  document.getElementById("filter-search").value = "";
  document.getElementById("filter-type").value = "";
  document.getElementById("filter-category").value = "";
  document.getElementById("filter-platform").value = "";
  document.getElementById("filter-start-date").value = "";
  document.getElementById("filter-end-date").value = "";
  applyFilters();
}

// --- KPI DISPLAY RENDERING ---
function updateKPIs() {
  let totalIncome = 0;
  let totalExpense = 0;
  let incomeCount = 0;
  let expenseCount = 0;
  let fixedCostsSum = 0;
  
  filteredTransactions.forEach(t => {
    const total = parseFloat(t.total) || 0;
    if (t.type === "Income") {
      totalIncome += total;
      incomeCount++;
    } else {
      totalExpense += total;
      expenseCount++;
      // Check if item is marked as Fixed Cost in Remark or Category
      if (t.remark?.toLowerCase().includes("fixed cost") || t.category === "ค่าอินเตอร์เน็ต") {
        fixedCostsSum += total;
      }
    }
  });
  
  const netBalance = totalIncome - totalExpense;
  
  // Calculate savings rate
  let savingsRate = 0;
  if (totalIncome > 0) {
    savingsRate = (netBalance / totalIncome) * 100;
  }
  
  // Update elements
  document.getElementById("kpi-total-income").innerText = formatCurrency(totalIncome);
  document.getElementById("kpi-income-sub").innerText = `${incomeCount} รายการ`;
  
  document.getElementById("kpi-total-expense").innerText = formatCurrency(totalExpense);
  document.getElementById("kpi-expense-sub").innerText = `${expenseCount} รายการ`;
  
  const balanceEl = document.getElementById("kpi-net-balance");
  balanceEl.innerText = formatCurrency(netBalance);
  if (netBalance >= 0) {
    balanceEl.style.color = "var(--color-income)";
  } else {
    balanceEl.style.color = "var(--color-expense)";
  }
  
  const percentIncome = totalIncome > 0 ? ((netBalance / totalIncome) * 100).toFixed(0) : 0;
  document.getElementById("kpi-balance-sub").innerText = netBalance >= 0 
    ? `คงเหลือสุทธิเป็นบวก คิดเป็น ${percentIncome}% ของรายรับ` 
    : `ยอดใช้จ่ายเกินรายรับอยู่ ${formatCurrency(Math.abs(netBalance))}`;
    
  document.getElementById("kpi-savings-rate").innerText = `${savingsRate.toFixed(1)}%`;
  document.getElementById("kpi-savings-sub").innerText = `รายจ่ายคงที่ (Fixed Cost): ${formatCurrency(fixedCostsSum)}`;
}

// --- CATEGORY BREAKDOWNS (VANILLA PROGRESS BARS) ---
function renderCategoryBreakdowns() {
  const container = document.getElementById("category-breakdown");
  
  // Extract expense transactions
  const expenses = filteredTransactions.filter(t => t.type === "Expense");
  const totalExpense = expenses.reduce((sum, t) => sum + (parseFloat(t.total) || 0), 0);
  
  if (expenses.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <i data-lucide="pie-chart" size="32"></i>
        <p>ไม่มีรายการใช้จ่ายตามหมวดหมู่ในตัวเลือกนี้</p>
      </div>`;
    lucide.createIcons();
    return;
  }
  
  // Sum by Category
  const catSums = {};
  expenses.forEach(e => {
    catSums[e.category] = (catSums[e.category] || 0) + parseFloat(e.total);
  });
  
  // Sort category breakdown descending
  const sortedCategories = Object.entries(catSums)
    .map(([cat, sum]) => ({ category: cat, total: sum, percent: totalExpense > 0 ? (sum / totalExpense) * 100 : 0 }))
    .sort((a, b) => b.total - a.total);
    
  container.innerHTML = "";
  
  // Accent colors pool for progress bars
  const colors = ["var(--color-primary)", "var(--color-secondary)", "#a855f7", "#eab308", "#f97316", "#3b82f6"];
  
  sortedCategories.forEach((item, index) => {
    const color = colors[index % colors.length];
    
    const div = document.createElement("div");
    div.className = "breakdown-item";
    div.innerHTML = `
      <div class="breakdown-meta">
        <div class="breakdown-name">
          <span style="display:inline-block; width:10px; height:10px; border-radius:50%; background:${color};"></span>
          ${item.category}
        </div>
        <div class="breakdown-amount">
          ${formatCurrency(item.total)} 
          <span style="color:var(--text-muted); font-size:0.8rem; font-weight:normal;">(${item.percent.toFixed(1)}%)</span>
        </div>
      </div>
      <div class="breakdown-bar-bg">
        <div class="breakdown-bar-fill" style="width: 0%; background: ${color};"></div>
      </div>
    `;
    container.appendChild(div);
    
    // Trigger animation in next tick
    setTimeout(() => {
      const fillBar = div.querySelector(".breakdown-bar-fill");
      if (fillBar) fillBar.style.width = `${item.percent}%`;
    }, 50);
  });
}

// --- DYNAMIC DATA VISUALIZATION (CHART.JS) ---
function renderCharts() {
  if (typeof Chart === "undefined") {
    console.warn("Chart.js is not loaded. Skipping chart rendering.");
    return;
  }
  const ctx = document.getElementById("monthlyChart").getContext("2d");
  
  // Destroy existing chart if it exists
  if (monthlyChart) {
    monthlyChart.destroy();
  }
  
  // Calculate sums by Month and Type
  // Group by YYYY-MM
  const monthlyData = {};
  
  // Sort oldest first for time sequence plotting
  const chronologicalTxns = [...filteredTransactions].sort((a, b) => a.date.localeCompare(b.date));
  
  chronologicalTxns.forEach(t => {
    if (!t.date) return;
    const monthKey = t.date.substring(0, 7); // "YYYY-MM"
    if (!monthlyData[monthKey]) {
      monthlyData[monthKey] = { income: 0, expense: 0 };
    }
    const val = parseFloat(t.total) || 0;
    if (t.type === "Income") {
      monthlyData[monthKey].income += val;
    } else {
      monthlyData[monthKey].expense += val;
    }
  });
  
  const labels = Object.keys(monthlyData);
  
  if (labels.length === 0) {
    // Render empty chart container placeholder text
    ctx.clearRect(0, 0, ctx.canvas.width, ctx.canvas.height);
    return;
  }
  
  // Map monthly data labels into Thai presentation names
  const thMonths = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
  const displayLabels = labels.map(key => {
    const [yr, mo] = key.split("-");
    const mName = thMonths[parseInt(mo, 10) - 1];
    return `${mName} ${yr.substring(2)}`;
  });
  
  const incomes = labels.map(k => monthlyData[k].income);
  const expenses = labels.map(k => monthlyData[k].expense);
  
  // Styles based on theme (light/dark)
  const isDark = document.documentElement.getAttribute("data-theme") === "dark";
  const gridColor = isDark ? "rgba(255, 255, 255, 0.05)" : "rgba(15, 23, 42, 0.05)";
  const textColor = isDark ? "#94a3b8" : "#475569";
  
  // Chart.js initialization
  monthlyChart = new Chart(ctx, {
    type: "bar",
    data: {
      labels: displayLabels,
      datasets: [
        {
          label: "รายรับ (Income)",
          data: incomes,
          backgroundColor: isDark ? "rgba(16, 185, 129, 0.7)" : "rgba(5, 150, 105, 0.85)",
          borderColor: "rgba(16, 185, 129, 1)",
          borderWidth: 1,
          borderRadius: 6
        },
        {
          label: "รายจ่าย (Expense)",
          data: expenses,
          backgroundColor: isDark ? "rgba(244, 63, 94, 0.7)" : "rgba(225, 29, 72, 0.85)",
          borderColor: "rgba(244, 63, 94, 1)",
          borderWidth: 1,
          borderRadius: 6
        }
      ]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      scales: {
        x: {
          grid: { display: false },
          ticks: { color: textColor, font: { family: "'Outfit', 'Noto Sans Thai'" } }
        },
        y: {
          grid: { color: gridColor },
          ticks: {
            color: textColor,
            font: { family: "'Outfit', 'Noto Sans Thai'" },
            callback: function(value) { return "฿" + value.toLocaleString(); }
          }
        }
      },
      plugins: {
        legend: {
          display: true,
          position: "top",
          labels: {
            color: isDark ? "#f8fafc" : "#0f172a",
            font: { family: "'Outfit', 'Noto Sans Thai'", size: 12 }
          }
        },
        tooltip: {
          backgroundColor: isDark ? "rgba(15, 23, 42, 0.95)" : "rgba(255, 255, 255, 0.95)",
          titleColor: isDark ? "#fff" : "#000",
          bodyColor: isDark ? "#fff" : "#000",
          borderWidth: 1,
          borderColor: isDark ? "rgba(255,255,255,0.1)" : "rgba(0,0,0,0.1)",
          callbacks: {
            label: function(context) {
              return " " + context.dataset.label.split(" ")[0] + ": " + formatCurrency(context.raw);
            }
          }
        }
      }
    }
  });
}

// --- TRANSACTIONS LIST / TABLE CONTROLLER ---
function renderTransactionsTable() {
  const tbody = document.getElementById("transactions-body");
  
  if (filteredTransactions.length === 0) {
    tbody.innerHTML = `
      <tr>
        <td colspan="8">
          <div class="empty-state">
            <i data-lucide="inbox" size="32"></i>
            <p>ไม่พบประวัติรายการหรือข้อมูลตามหมวดหมู่ที่เลือก</p>
          </div>
        </td>
      </tr>`;
    document.getElementById("pagination-info").innerText = "แสดงรายการ 0 - 0 จากทั้งหมด 0 รายการ";
    document.getElementById("btn-prev-page").disabled = true;
    document.getElementById("btn-next-page").disabled = true;
    lucide.createIcons();
    return;
  }
  
  const totalItems = filteredTransactions.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  
  // Clamp page bounds
  if (currentPage > totalPages) currentPage = totalPages;
  if (currentPage < 1) currentPage = 1;
  
  const startIndex = (currentPage - 1) * itemsPerPage;
  const endIndex = Math.min(startIndex + itemsPerPage, totalItems);
  
  const pageItems = filteredTransactions.slice(startIndex, endIndex);
  
  tbody.innerHTML = "";
  
  pageItems.forEach(t => {
    const tr = document.createElement("tr");
    
    // Format presentation date (e.g. 2026-05-02 -> 02/05/2026)
    const [yr, mm, dd] = t.date.split("-");
    const displayDate = `${parseInt(dd, 10)}/${parseInt(mm, 10)}/${yr}`;
    
    const isIncome = t.type === "Income";
    const typeClass = isIncome ? "income" : "expense";
    const typeText = isIncome ? "รายรับ" : "รายจ่าย";
    
    // Amount formatting with symbol prefix
    const amtPrefix = isIncome ? "+ " : "- ";
    const amtClass = isIncome ? "income" : "expense";
    
    tr.innerHTML = `
      <td>${displayDate}</td>
      <td>
        <span class="type-tag ${typeClass}">
          <i data-lucide="${isIncome ? "arrow-up-right" : "arrow-down-left"}" size="12"></i>
          ${typeText}
        </span>
      </td>
      <td><span class="platform-tag">${t.platform}</span></td>
      <td class="amount-text ${amtClass}">${amtPrefix}${formatCurrency(t.total).replace("฿", "")}</td>
      <td><strong>${t.category}</strong></td>
      <td>${t.location || '<span style="color:var(--text-muted); font-style:italic;">-</span>'}</td>
      <td>
        <span style="font-size:0.85rem; color:var(--text-secondary);">
          ${t.remark || ''}
        </span>
      </td>
      <td>
        <div class="action-buttons">
          <button class="action-btn edit-btn" title="แก้ไขรายการ" onclick="openEditModal('${t.id}')">
            <i data-lucide="edit-3" size="16"></i>
          </button>
          <button class="action-btn delete-btn" title="ลบรายการ" onclick="confirmDelete('${t.id}', '${t.category}', ${t.total})">
            <i data-lucide="trash-2" size="16"></i>
          </button>
        </div>
      </td>
    `;
    tbody.appendChild(tr);
  });
  
  // Update pagination info text and button triggers
  document.getElementById("pagination-info").innerText = `แสดงรายการ ${startIndex + 1} - ${endIndex} จากทั้งหมด ${totalItems} รายการ`;
  document.getElementById("btn-prev-page").disabled = currentPage === 1;
  document.getElementById("btn-next-page").disabled = currentPage === totalPages;
  
  lucide.createIcons();
}

// --- MODAL DIALOG ENGINE ---

function openAddModal() {
  document.getElementById("modal-title").innerText = "เพิ่มรายการธุรกรรมใหม่";
  document.getElementById("form-id").value = "";
  
  // Preset default form values
  const today = new Date();
  const tzOffset = today.getTimezoneOffset() * 60000; // local time zone offset
  const localISODate = (new Date(today - tzOffset)).toISOString().split("T")[0];
  
  document.getElementById("form-date").value = localISODate;
  document.getElementById("form-total").value = "";
  document.getElementById("form-platform").value = "";
  document.getElementById("form-category").value = "";
  document.getElementById("form-location").value = "";
  document.getElementById("form-remark").value = "";
  
  // Reset form switch type
  setFormSwitch("Expense");
  
  document.getElementById("txn-modal").classList.add("active");
}

window.openEditModal = function(id) {
  const txn = transactions.find(t => t.id === id);
  if (!txn) return;
  
  document.getElementById("modal-title").innerText = "แก้ไขรายการธุรกรรม";
  document.getElementById("form-id").value = txn.id;
  document.getElementById("form-date").value = txn.date;
  document.getElementById("form-total").value = txn.total;
  document.getElementById("form-platform").value = txn.platform;
  document.getElementById("form-category").value = txn.category;
  document.getElementById("form-location").value = txn.location || "";
  document.getElementById("form-remark").value = txn.remark || "";
  
  setFormSwitch(txn.type);
  
  document.getElementById("txn-modal").classList.add("active");
};

function closeModal() {
  document.getElementById("txn-modal").classList.remove("active");
  // Hide suggestion list boxes if open
  closeAllSuggestions();
}

function setFormSwitch(type) {
  const expenseBtn = document.getElementById("form-switch-expense");
  const incomeBtn = document.getElementById("form-switch-income");
  const typeField = document.getElementById("form-type");
  
  typeField.value = type;
  
  if (type === "Expense") {
    expenseBtn.classList.add("active");
    incomeBtn.classList.remove("active");
  } else {
    incomeBtn.classList.add("active");
    expenseBtn.classList.remove("active");
  }
}

// User Action verification popups
window.confirmDelete = function(id, category, amount) {
  const formattedText = `คุณแน่ใจหรือไม่ที่จะต้องการลบรายการ:\n"${category}" จำนวน ${formatCurrency(amount)}?`;
  if (confirm(formattedText)) {
    deleteTransaction(id);
  }
};

// --- FORM AUTOLOAD & AUTOCOMPLETE ENGINE ---
function initAutocomplete() {
  const fields = ["platform", "category", "location"];
  
  fields.forEach(field => {
    const input = document.getElementById(`form-${field}`);
    const list = document.getElementById(`suggestions-${field}`);
    
    input.addEventListener("input", function() {
      const val = this.value.trim().toLowerCase();
      if (!val) {
        list.classList.remove("active");
        return;
      }
      
      const suggestions = window.autocompleteLists[field] || [];
      const matches = suggestions.filter(s => s.toLowerCase().includes(val)).slice(0, 5);
      
      if (matches.length === 0) {
        list.classList.remove("active");
        return;
      }
      
      list.innerHTML = "";
      matches.forEach(m => {
        const item = document.createElement("div");
        item.className = "suggestion-item";
        item.innerText = m;
        item.addEventListener("click", () => {
          input.value = m;
          list.classList.remove("active");
        });
        list.appendChild(item);
      });
      list.classList.add("active");
    });
    
    // Hide list on clicking outside field
    document.addEventListener("click", (e) => {
      if (e.target !== input && e.target !== list) {
        list.classList.remove("active");
      }
    });
  });
}

function closeAllSuggestions() {
  document.getElementById("suggestions-platform").classList.remove("active");
  document.getElementById("suggestions-category").classList.remove("active");
  document.getElementById("suggestions-location").classList.remove("active");
}

// Export parsed filters dataset as CSV downloaded file
function exportCSV() {
  if (filteredTransactions.length === 0) return;
  
  const headers = ["ID", "Date", "Type", "Platform", "Total (Baht)", "Category", "Location", "Remark"];
  const csvRows = [headers.join(",")];
  
  filteredTransactions.forEach(t => {
    const [yr, mm, dd] = t.date.split("-");
    // Format back to D/M/YYYY for localized excel export compatibility
    const formattedDate = `${parseInt(dd, 10)}/${parseInt(mm, 10)}/${yr}`;
    
    // Clean string values from double quotes
    const escape = (val) => {
      if (val === null || val === undefined) return "";
      const text = val.toString().replace(/"/g, '""');
      return text.includes(",") || text.includes("\n") || text.includes('"') ? `"${text}"` : text;
    };
    
    const row = [
      escape(t.id),
      escape(formattedDate),
      escape(t.type),
      escape(t.platform),
      escape(t.total.toFixed(2)),
      escape(t.category),
      escape(t.location),
      escape(t.remark)
    ];
    csvRows.push(row.join(","));
  });
  
  const csvString = "\ufeff" + csvRows.join("\n"); // Include BOM for proper Thai characters Excel support
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  
  const link = document.createElement("a");
  const url = URL.createObjectURL(blob);
  
  const today = new Date().toISOString().split("T")[0];
  link.setAttribute("href", url);
  link.setAttribute("download", `wealth_tracker_export_${today}.csv`);
  link.style.visibility = "hidden";
  
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

// --- SETUP EVENT LISTENERS ON PAGE LOAD ---
document.addEventListener("DOMContentLoaded", async () => {
  initTheme();
  
  // Bind Mode and check API backend responsiveness
  await checkApiMode();
  await loadTransactions();
  initAutocomplete();
  
  // Theme Toggle
  document.getElementById("btn-toggle-theme").addEventListener("click", () => {
    const current = document.documentElement.getAttribute("data-theme");
    const next = current === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", next);
    localStorage.setItem("wt_theme", next);
    updateThemeIcon();
    
    // Redraw chart to update grids and labels colors
    renderCharts();
  });
  

  
  // Filters listeners
  document.getElementById("filter-search").addEventListener("input", applyFilters);
  document.getElementById("filter-type").addEventListener("change", applyFilters);
  document.getElementById("filter-category").addEventListener("change", applyFilters);
  document.getElementById("filter-platform").addEventListener("change", applyFilters);
  document.getElementById("filter-start-date").addEventListener("change", applyFilters);
  document.getElementById("filter-end-date").addEventListener("change", applyFilters);
  
  document.getElementById("btn-reset-filters").addEventListener("click", resetFilters);
  
  // Export CSV
  document.getElementById("btn-export-csv").addEventListener("click", exportCSV);
  
  // Modal buttons
  document.getElementById("btn-new-transaction").addEventListener("click", openAddModal);
  document.getElementById("btn-close-modal").addEventListener("click", closeModal);
  document.getElementById("btn-cancel-form").addEventListener("click", closeModal);
  
  // Switch Expense / Income inside form
  document.getElementById("form-switch-expense").addEventListener("click", () => setFormSwitch("Expense"));
  document.getElementById("form-switch-income").addEventListener("click", () => setFormSwitch("Income"));
  
  // Pagination controls
  document.getElementById("btn-prev-page").addEventListener("click", () => {
    if (currentPage > 1) {
      currentPage--;
      renderTransactionsTable();
    }
  });
  document.getElementById("btn-next-page").addEventListener("click", () => {
    currentPage++;
    renderTransactionsTable();
  });
  
  // Handle form submission
  document.getElementById("txn-form").addEventListener("submit", async (e) => {
    e.preventDefault();
    
    const txnData = {
      id: document.getElementById("form-id").value || undefined,
      date: document.getElementById("form-date").value,
      type: document.getElementById("form-type").value,
      platform: document.getElementById("form-platform").value.trim(),
      total: parseFloat(document.getElementById("form-total").value),
      category: document.getElementById("form-category").value.trim(),
      location: document.getElementById("form-location").value.trim(),
      remark: document.getElementById("form-remark").value.trim()
    };
    
    if (!txnData.date || !txnData.platform || isNaN(txnData.total) || !txnData.category) {
      showStatus("กรุณากรอกข้อมูลในช่องที่จำเป็นให้ครบถ้วน", "error");
      return;
    }
    
    const success = await saveTransaction(txnData);
    if (success) {
      closeModal();
    }
  });
  
  // Initialize Lucide icons on page load completion
  lucide.createIcons();
});
